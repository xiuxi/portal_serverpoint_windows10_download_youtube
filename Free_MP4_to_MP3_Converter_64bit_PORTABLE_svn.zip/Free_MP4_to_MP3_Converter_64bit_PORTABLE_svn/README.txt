Name: Free MP4 to MP3 Converter (32/64-bit)
Version: 1.7
License: Freeware
Date: 25.01.2021
Author: Jacek Pazera
Web page: https://www.pazera-software.com/products/mp4-to-mp3/
Quick start: https://www.pazera-software.com/products/mp4-to-mp3/quickstart.php

////////////////////////////////////////////////////////////////////////////////

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

////////////////////////////////////////////////////////////////////////////////

This program uses the following open source software:
   1. FFmpeg, licensed under the GNU Lesser General Public License (LGPL) version 2.1 available at https://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
   2. MediaInfo library, licensed under the MediaInfo(Lib) License available at https://mediaarea.net/en/MediaInfo/License
   3. JPPack: https://github.com/jackdp/JPPack
   4: JPLib: https://github.com/jackdp/JPLib
   5. SpTBXLib: https://github.com/SilverpointDev/sptbxlib
   6. Toolbar200: https://www.jrsoftware.org/tb2k.php
   7. Tags Library 1.0.78.133: https://www.3delite.hu/Object%20Pascal%20Developer%20Resources/TagsLibrary.html
   8. PngComponents: https://github.com/UweRaabe/PngComponents
   9. VCL Styles Utils: https://github.com/RRUZ/vcl-styles-utils
  10. Delphi Detours Library: https://github.com/MahdiSafsafi/DDetours
  11. Shell Folders Unit: https://www.delphidabbler.com/software/shellfolders
  12. DzHTMLText2: https://github.com/jackdp/DzHTMLText2
